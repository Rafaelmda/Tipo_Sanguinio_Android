# Tipo sanguineo
# Aplicação de estudo feito durante a aula de android.
